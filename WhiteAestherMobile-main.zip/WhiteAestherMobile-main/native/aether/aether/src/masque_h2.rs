use std::net::IpAddr;
use std::net::Ipv4Addr;
use std::net::SocketAddr;
use std::sync::atomic::{AtomicU8, Ordering};
use std::time::{Duration, Instant};

use boring::pkey::PKey;
use boring::ssl::{SslConnector, SslMethod};
use boring::x509::X509;
use bytes::Bytes;
use http::Method;
use tokio::net::TcpStream;
use tokio::sync::{mpsc, oneshot};

use crate::consts;
use crate::error::{AetherError, Result};
use crate::fragment::{FragmentConfig, FragmentingStream};
use crate::masque::{self, Capsule, CapsuleParser};
use crate::quic::{AssignedAddr, Control, Internals};
use crate::tls;

/// ALPN: HTTP/2, then HTTP/1.1, as Chrome offers them; the edge picks HTTP/2, which the
/// tunnel speaks.
const H2_ALPN: &[u8] = b"\x02h2\x08http/1.1";

/// The largest DATA frame we let the edge send us. The h2 default is the RFC
/// minimum of 16 KiB, so a fast stream pays four times the frame headers and
/// four times the wakeups it needs to.
const H2_MAX_FRAME_SIZE: u32 = 64 * 1024;

/// How much a single write to the edge may carry. Every capsule sent on its own
/// costs a DATA frame, a TLS record and a TCP segment, which for a 1280-byte
/// packet is mostly overhead, so packets already queued behind one another are
/// gathered up to this much and sent together.
const H2_SEND_BATCH_BYTES: usize = 32 * 1024;

/// How long the tunnel waits, on a clean shutdown, for the send task to put the
/// closing frame on the wire.
const SENDER_CLOSE_GRACE: Duration = Duration::from_millis(250);

/// Whether a handshake that failed with `message` was turned down for its
/// ECHConfigList, which BoringSSL reports as ECH_REJECTED once the handshake that
/// turned it down is over. Only then does it hand out the retry configs the server
/// sent, if any; asked after any other failure, it hands out a placeholder.
fn rejected_ech(message: &str) -> bool {
    message.contains("ECH_REJECTED")
}

struct AbortOnDrop(tokio::task::AbortHandle);

impl Drop for AbortOnDrop {
    fn drop(&mut self) {
        self.0.abort();
    }
}

/// Everything the send task accepts besides the packets on the outbound queue.
enum SenderMsg {
    /// A capsule that is already framed, used by the data-plane probes.
    Capsule(Bytes),
    /// End the request stream and stop.
    Finish,
}

/// HTTP/2 flow control decides how much data the edge may have in flight toward
/// us before it has to stop and wait for an acknowledgement, which puts a hard
/// ceiling of window / round-trip-time on a download. The h2 crate defaults to
/// the RFC minimum of 64 KiB on both the stream and the connection, and 64 KiB
/// over a 130 ms round trip is about 500 KB/s however fast the line underneath
/// really is. QUIC and WireGuard never run into this because their windows are
/// megabytes wide; this is what puts HTTP/2 on the same footing.
fn h2_builder() -> h2::client::Builder {
    let mut builder = h2::client::Builder::new();
    builder
        .initial_window_size(crate::sysprofile::h2_stream_window_bytes())
        .initial_connection_window_size(crate::sysprofile::h2_connection_window_bytes())
        .max_frame_size(H2_MAX_FRAME_SIZE);
    builder
}

pub struct H2TunnelConfig {
    pub peer: SocketAddr,
    pub sni: String,
    pub authority: String,
    pub path: String,
    pub cert_pem: Vec<u8>,
    pub key_pem: Vec<u8>,
    pub local_ipv4: Ipv4Addr,
    pub quiet: bool,
    pub pin_endpoint: bool,
    pub expected_pins: Vec<Vec<u8>>,
    /// The ECHConfigList the handshake offers: the session's, see `tls::session_ech`, or
    /// none, as on the inner hop of masque-in-masque, which rides inside the outer one.
    pub ech_config_list: Option<Vec<u8>>,
}

fn log_or_debug(quiet: bool, msg: String) {
    if quiet {
        log::debug!("{msg}");
    } else {
        log::info!("{msg}");
    }
}

fn data_check_enabled() -> bool {
    std::env::var("AETHER_MASQUE_NO_DATA_CHECK").is_err()
}

pub(crate) fn validation_timeout() -> Duration {
    let secs = std::env::var("AETHER_MASQUE_VALIDATE_SECS")
        .ok()
        .and_then(|v| v.parse::<u64>().ok())
        .filter(|&v| v > 0)
        .map(|v| v.min(86_400))
        .unwrap_or(10);
    Duration::from_secs(secs)
}

const DATA_PROBE_REQUIRED_SUCCESSES: u32 = 2;

/// How long a data-plane probe waits for its answer before another is sent.
///
/// The probe is one datagram, and a datagram can be lost. The tunnel has always
/// sent it again on this interval; the check an endpoint has to pass before it
/// is chosen sent it once and then waited, so a single lost probe cost a
/// working edge its whole timeout and the verdict "does not answer". That check
/// is every H2 candidate the scanner tries and every remembered or assigned
/// endpoint verified before use -- on the framing most filtered networks leave
/// open.
const DATA_PROBE_RESEND: Duration = Duration::from_millis(700);

fn h2_keepalive_interval() -> Duration {
    let secs = std::env::var("AETHER_MASQUE_H2_KEEPALIVE_SECS")
        .ok()
        .and_then(|v| v.parse::<u64>().ok())
        .filter(|&v| v > 0)
        .map(|v| v.min(86_400))
        .unwrap_or(15);
    Duration::from_secs(secs)
}

fn h2_keepalive_timeout() -> Duration {
    let secs = std::env::var("AETHER_MASQUE_H2_KEEPALIVE_TIMEOUT_SECS")
        .ok()
        .and_then(|v| v.parse::<u64>().ok())
        .filter(|&v| v > 0)
        .map(|v| v.min(86_400))
        .unwrap_or(20);
    Duration::from_secs(secs)
}

pub fn enabled() -> bool {
    match std::env::var("AETHER_MASQUE_HTTP2") {
        Ok(v) => {
            let v = v.trim().to_lowercase();
            v == "1" || v == "true" || v == "h2" || v == "yes" || v == "on"
        }
        Err(_) => false,
    }
}

pub fn h2_peer(quic_peer: SocketAddr) -> SocketAddr {
    if let Ok(v) = std::env::var("AETHER_MASQUE_H2_PEER") {
        if let Ok(addr) = v.trim().parse::<SocketAddr>() {
            return addr;
        }
    }
    quic_peer
}

fn build_tls(cfg: &H2TunnelConfig) -> Result<boring::ssl::ConnectConfiguration> {
    let mut builder =
        SslConnector::builder(SslMethod::tls()).map_err(|e| AetherError::Tls(e.to_string()))?;

    // The core's TLS fingerprint, with --tls-ciphers, --tls-groups and --disable-grease.
    let fingerprint = tls::Fingerprint::configured();
    fingerprint.apply(&mut builder, H2_ALPN)?;
    if crate::hello_shape::HelloShape::from_env().is_some() {
        builder.set_grease_enabled(false);
        builder.set_permute_extensions(false);
        if tls::TLS_CIPHERS.configured().is_none() {
            tls::set_tls12_ciphers(&mut builder, "ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305")?;
        }
        if std::env::var("AETHER_TLS_GROUPS")
            .unwrap_or_default()
            .trim()
            .is_empty()
        {
            builder
                .set_curves_list("X25519:P-256:P-384")
                .map_err(|e| AetherError::Tls(e.to_string()))?;
        }
    }

    let cert = X509::from_pem(&cfg.cert_pem).map_err(|e| AetherError::Tls(e.to_string()))?;
    let key =
        PKey::private_key_from_pem(&cfg.key_pem).map_err(|e| AetherError::Tls(e.to_string()))?;
    builder
        .set_certificate(&cert)
        .map_err(|e| AetherError::Tls(e.to_string()))?;
    builder
        .set_private_key(&key)
        .map_err(|e| AetherError::Tls(e.to_string()))?;

    // Install TLS verification:
    // pin_endpoint=true with pins: pin-based verification (SNI can be spoofed)
    // pin_endpoint=false: SslVerifyMode::NONE (default, required for Cloudflare MASQUE edges)
    let pin_refs: Vec<&[u8]> = cfg.expected_pins.iter().map(|p| p.as_slice()).collect();
    tls::install_verification(&mut *builder, cfg.pin_endpoint, &pin_refs)?;

    let connector = builder.build();
    let mut config = connector
        .configure()
        .map_err(|e| AetherError::Tls(e.to_string()))?;

    // MASQUE authenticates the gateway by its SPKI pin rather than the visible SNI.
    config.set_verify_hostname(false);
    config.set_use_server_name_indication(true);
    fingerprint.prepare(&mut config, H2_ALPN)?;

    Ok(config)
}

/// What the edge said when it refused, in one line.
///
/// Headers as well as the status, because Cloudflare explains itself in
/// `cf-`-prefixed ones and a number on its own cannot tell a blocked network
/// from a request it no longer accepts.
fn describe_refusal(response: &http::Response<h2::RecvStream>) -> String {
    let mut described = format!("h2 connect-ip status {}", response.status().as_u16());
    for (name, value) in response.headers() {
        let name = name.as_str();
        if name.starts_with("cf-") || name == "reason" || name == "x-error" {
            described.push_str(&format!(
                "; {name}={}",
                value.to_str().unwrap_or("<not text>")
            ));
        }
    }
    described
}

fn build_connect_request(cfg: &H2TunnelConfig) -> Result<http::Request<()>> {
    let authority = format!("{}:443", cfg.authority);
    let uri = format!("https://{}", authority);
    http::Request::builder()
        .method(Method::CONNECT)
        .uri(uri)
        .header("cf-connect-proto", consts::CF_CONNECT_PROTOCOL)
        .header("pq-enabled", "false")
        .header("user-agent", "")
        .body(())
        .map_err(|e| AetherError::Masque(format!("build request: {e}")))
}

pub async fn dial(peer: std::net::SocketAddr) -> Result<TcpStream> {
    match crate::upstream::configured() {
        Some(proxy) => proxy.connect(peer).await,
        // Not TcpStream::connect: the socket has to be protected before the
        // SYN leaves, or on Android it goes out through the tunnel this
        // connection is being made to build. egress does that -- see its
        // apply().
        None => crate::egress::tcp_connect(peer)
            .await
            .map_err(AetherError::Io),
    }
}

/// Opens the TLS connection the HTTP/2 carrier runs on: dials the peer and shakes
/// hands, offering the ECHConfigList of `cfg` when it has one. A server that turns that
/// config down hands back the one it holds now; the handshake is made once more with
/// it, and later handshakes of the session offer it as well, on either carrier.
async fn connect_tls(
    cfg: &H2TunnelConfig,
    fragment: FragmentConfig,
) -> Result<tokio_boring::SslStream<FragmentingStream<TcpStream>>> {
    connect_tls_with(cfg, fragment, None, None).await
}

/// [`connect_tls`], with the TCP connect held to `dial_within` and the step it
/// has reached written to `stage`, for a check that has to say where it stalled.
async fn connect_tls_with(
    cfg: &H2TunnelConfig,
    fragment: FragmentConfig,
    dial_within: Option<Duration>,
    stage: Option<&AtomicU8>,
) -> Result<tokio_boring::SslStream<FragmentingStream<TcpStream>>> {
    let mut ech = cfg.ech_config_list.clone();
    let mut retried = false;
    loop {
        let mut tls_config = build_tls(cfg)?;
        if let Some(list) = &ech {
            // BoringSSL takes a key it offers nothing from, and the name would go in the clear.
            tls::ensure_offerable(list)?;
            tls_config
                .set_ech_config_list(list)
                .map_err(|e| AetherError::Tls(format!("h2 ech config: {e}")))?;
        }
        let tcp = match dial_within {
            Some(limit) => tokio::time::timeout(limit, dial(cfg.peer))
                .await
                .map_err(|_| {
                    AetherError::Io(std::io::Error::new(
                        std::io::ErrorKind::TimedOut,
                        format!(
                            "tcp connect to {} timed out after {}s",
                            cfg.peer,
                            limit.as_secs()
                        ),
                    ))
                })??,
            None => dial(cfg.peer).await?,
        };
        if let Some(stage) = stage {
            stage.store(STAGE_TLS, Ordering::Relaxed);
        }
        let _ = tcp.set_nodelay(true);
        let stream = FragmentingStream::new(tcp, fragment);
        match tokio_boring::connect(tls_config, &cfg.sni, stream).await {
            Ok(tls) => {
                // Some existing tunnel edges omit ALPN. Retain that fallback;
                // an explicitly negotiated HTTP/1.1 cannot carry H2 frames.
                if tls
                    .ssl()
                    .selected_alpn_protocol()
                    .is_some_and(|protocol| protocol != b"h2")
                {
                    return Err(AetherError::Masque(format!(
                        "h2 ALPN: gateway selected {} instead of h2",
                        tls.ssl()
                            .selected_alpn_protocol()
                            .map(|protocol| String::from_utf8_lossy(protocol).into_owned())
                            .unwrap_or_else(|| "no protocol".into()),
                    )));
                }
                if ech.is_some() {
                    // Nothing goes over a handshake that went without the key it was given.
                    if !tls.ssl().ech_accepted() {
                        return Err(AetherError::Ech("the handshake went without ECH".into()));
                    }
                    log_or_debug(cfg.quiet, "[h2] ech accepted".to_string());
                }
                return Ok(tls);
            }
            Err(e) => {
                let message = e.to_string();
                let retry = if !retried && ech.is_some() && rejected_ech(&message) {
                    e.ssl()
                        .and_then(|ssl| ssl.get_ech_retry_configs())
                        .filter(|configs| !configs.is_empty())
                        .and_then(tls::usable_retry)
                } else {
                    None
                };
                let Some(retry) = retry else {
                    return Err(AetherError::Tls(format!("h2 tls handshake: {message}")));
                };
                log_or_debug(
                    cfg.quiet,
                    format!(
                        "[h2] ech_required: retrying the handshake with the server's retry_configs ({} bytes)",
                        retry.len()
                    ),
                );
                tls::adopt_ech_retry(&retry);
                ech = Some(retry);
                retried = true;
            }
        }
    }
}

// How far an endpoint check got. A timeout that names the step it stalled on
// tells a silent address from a slow edge, which "h2 verify timeout" did not.
const STAGE_TCP: u8 = 0;
const STAGE_TLS: u8 = 1;
const STAGE_H2: u8 = 2;
const STAGE_CONNECT: u8 = 3;
const STAGE_DATA: u8 = 4;

fn stalled_at(stage: u8) -> &'static str {
    match stage {
        STAGE_TCP => "no TCP connection",
        STAGE_TLS => "no answer to the TLS handshake",
        STAGE_H2 => "no HTTP/2 answer after TLS",
        STAGE_CONNECT => "no answer to the connect-ip request",
        _ => "no data came back through the tunnel",
    }
}

pub async fn verify_h2(cfg: &H2TunnelConfig, timeout: Duration) -> Result<Duration> {
    verify_h2_bounded(cfg, None, timeout).await
}

/// [`verify_h2`], with the TCP connect held to `dial_within` inside `timeout`.
///
/// An address that never answers the connect is given up on at `dial_within`,
/// as before; one that does connect gets the rest of `timeout` for TLS, the
/// connect-ip request and the data-plane answers, which on a long, lossy path
/// is several seconds of retransmission on its own.
pub async fn verify_h2_bounded(
    cfg: &H2TunnelConfig,
    dial_within: Option<Duration>,
    timeout: Duration,
) -> Result<Duration> {
    let start = Instant::now();
    let data_check = data_check_enabled();
    let stage = AtomicU8::new(STAGE_TCP);

    let attempt = async {
        let tls =
            connect_tls_with(cfg, FragmentConfig::from_env(), dial_within, Some(&stage)).await?;
        stage.store(STAGE_H2, Ordering::Relaxed);
        let (h2, connection) = h2_builder()
            .handshake(tls)
            .await
            .map_err(|e| AetherError::Masque(format!("h2 handshake: {e}")))?;
        let _driver = AbortOnDrop(
            tokio::spawn(async move {
                let _ = connection.await;
            })
            .abort_handle(),
        );
        let mut h2 = h2
            .ready()
            .await
            .map_err(|e| AetherError::Masque(format!("h2 ready: {e}")))?;
        stage.store(STAGE_CONNECT, Ordering::Relaxed);
        let req = build_connect_request(cfg)?;
        let (resp_fut, mut send_stream) = h2
            .send_request(req, false)
            .map_err(|e| AetherError::Masque(format!("send_request: {e}")))?;
        let response = resp_fut
            .await
            .map_err(|e| AetherError::Masque(format!("await response: {e}")))?;
        let status = response.status();
        if !status.is_success() {
            // The edge's own reason, not just the number. A bare status is what
            // several thousand probes collapse into "no clean endpoint found",
            // and it is the difference between a network that is blocking us
            // and a request contract that has moved.
            return Err(AetherError::Masque(describe_refusal(&response)));
        }

        if !data_check {
            return Ok(());
        }

        stage.store(STAGE_DATA, Ordering::Relaxed);
        let mut recv_body = response.into_body();
        let probe = masque::build_dns_probe_packet(cfg.local_ipv4);
        prove_data_plane(&mut recv_body, &mut send_stream, &probe).await
    };

    match tokio::time::timeout(timeout, attempt).await {
        Ok(Ok(())) => Ok(start.elapsed()),
        Ok(Err(e)) => Err(e),
        Err(_) => Err(AetherError::Other(format!(
            "h2 verify timeout after {}s: {}",
            timeout.as_secs(),
            stalled_at(stage.load(Ordering::Relaxed))
        ))),
    }
}

/// Whether a check failed on a refusal or reset that the next connection may
/// well not meet.
///
/// A filtered path resets a share of connections at random, and an edge sheds
/// load the same way; measured on one such network, about one connect in seven
/// to a working edge was refused. One attempt turned each of those into "this
/// endpoint does not work". A certificate, an HTTP refusal or a timeout is an
/// answer, and is not asked twice.
pub(crate) fn refused_in_passing(error: &AetherError) -> bool {
    if let AetherError::Io(e) = error {
        return matches!(
            e.kind(),
            std::io::ErrorKind::ConnectionRefused
                | std::io::ErrorKind::ConnectionReset
                | std::io::ErrorKind::ConnectionAborted
        );
    }
    // A reset that lands mid-handshake arrives inside a TLS error.
    let text = error.to_string().to_ascii_lowercase();
    matches!(error, AetherError::Tls(_))
        && (text.contains("unexpected eof")
            || text.contains("connection reset")
            || text.contains("forcibly closed"))
}

/// Runs `check`, and once more after a short pause if it was refused in passing
/// (see [`refused_in_passing`]) within `quickly`. A refusal that took longer is
/// not cheap to ask again, and the caller's budget was sized for one try.
pub(crate) async fn once_more_if_refused<T, F, Fut>(quickly: Duration, mut check: F) -> Result<T>
where
    F: FnMut() -> Fut,
    Fut: std::future::Future<Output = Result<T>>,
{
    let started = Instant::now();
    match check().await {
        Err(error) if refused_in_passing(&error) && started.elapsed() < quickly => {
            log::debug!("[*] refused in passing ({error}); checking once more");
            tokio::time::sleep(Duration::from_millis(250)).await;
            check().await
        }
        other => other,
    }
}

/// Sends `probe` through an open connect-ip stream until enough answers have
/// come back to call the edge's data plane working.
///
/// Returns only on an answer or on the stream failing; the caller's timeout is
/// what ends a wait for an edge that never answers.
async fn prove_data_plane(
    recv_body: &mut h2::RecvStream,
    send_stream: &mut h2::SendStream<Bytes>,
    probe: &[u8],
) -> Result<()> {
    let mut capsules = CapsuleParser::new();
    let framed = masque::encode_datagram_capsule(probe);
    send_capsule(send_stream, Bytes::from(framed)).await?;

    let mut probe_successes: u32 = 0;
    // Sent again until answered, as the tunnel itself does. The first tick of
    // an interval is immediate and the probe has just gone, so it is spent here
    // rather than sending a second copy at once.
    let mut resend = tokio::time::interval(DATA_PROBE_RESEND);
    resend.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    resend.tick().await;

    loop {
        tokio::select! {
            biased;

            data = futures::future::poll_fn(|cx| recv_body.poll_data(cx)) => {
                match data {
                    Some(Ok(chunk)) => {
                        let _ = recv_body.flow_control().release_capacity(chunk.len());
                        capsules.push(&chunk);
                        loop {
                            match capsules.next() {
                                Ok(Some(Capsule::Datagram(_))) => {
                                    probe_successes += 1;
                                    if probe_successes >= DATA_PROBE_REQUIRED_SUCCESSES {
                                        return Ok(());
                                    }
                                    let framed = masque::encode_datagram_capsule(probe);
                                    send_capsule(send_stream, Bytes::from(framed)).await?;
                                    resend.reset();
                                }
                                Ok(Some(_)) => continue,
                                Ok(None) => break,
                                Err(_) => break,
                            }
                        }
                    }
                    Some(Err(e)) => {
                        return Err(AetherError::Masque(format!("h2 body: {e}")));
                    }
                    None => {
                        return Err(AetherError::Masque("h2 stream closed before data".into()));
                    }
                }
            }

            _ = resend.tick() => {
                let framed = masque::encode_datagram_capsule(probe);
                send_capsule(send_stream, Bytes::from(framed)).await?;
            }
        }
    }
}

async fn sleep_until_deadline(deadline: Option<Instant>) {
    match deadline {
        Some(at) => tokio::time::sleep_until(tokio::time::Instant::from_std(at)).await,
        None => std::future::pending().await,
    }
}

pub async fn run(
    cfg: H2TunnelConfig,
    internals: Internals,
    addr_tx: Option<mpsc::Sender<AssignedAddr>>,
    ready_tx: Option<oneshot::Sender<()>>,
) -> Result<()> {
    let (outbound_rx, inbound_tx, mut ctrl_rx) = internals.into_parts();
    let quiet = cfg.quiet;
    let data_check = data_check_enabled();
    let probe_packet = masque::build_dns_probe_packet(cfg.local_ipv4);
    let mut ready_tx = ready_tx;
    let mut ready_fired = false;
    let mut validate_successes: u32 = 0;

    log_or_debug(quiet, format!("[h2] connecting tcp to {}", cfg.peer));

    let frag_cfg = FragmentConfig::from_env();
    if frag_cfg.enabled {
        log_or_debug(
            quiet,
            format!(
                "[h2] fragmenting client hello: size={}..{} delay={}..{}ms",
                frag_cfg.size_min, frag_cfg.size_max, frag_cfg.delay_min_ms, frag_cfg.delay_max_ms
            ),
        );
    }

    let tls = connect_tls(&cfg, frag_cfg).await?;
    log_or_debug(
        quiet,
        format!(
            "[h2] tls established; alpn={}",
            String::from_utf8_lossy(tls.ssl().selected_alpn_protocol().unwrap_or(b""))
        ),
    );

    let (h2, mut connection) = h2_builder()
        .handshake(tls)
        .await
        .map_err(|e| AetherError::Masque(format!("h2 handshake: {e}")))?;

    // Worth saying out loud: this is the ceiling on a download, at
    // window / round-trip-time, and it is the first thing to look at when the
    // HTTP/2 carrier is slower than the line underneath it.
    log_or_debug(
        quiet,
        format!(
            "[h2] flow control: stream window {}KB, connection window {}KB, max frame {}KB",
            crate::sysprofile::h2_stream_window_bytes() / 1024,
            crate::sysprofile::h2_connection_window_bytes() / 1024,
            H2_MAX_FRAME_SIZE / 1024,
        ),
    );

    let mut ping_pong = connection
        .ping_pong()
        .ok_or_else(|| AetherError::Masque("h2 connection does not support ping".into()))?;

    let driver_handle = tokio::spawn(async move {
        if let Err(e) = connection.await {
            log::debug!("[h2] connection driver ended: {e}");
        }
    });
    let _driver_guard = AbortOnDrop(driver_handle.abort_handle());

    let mut h2 = h2
        .ready()
        .await
        .map_err(|e| AetherError::Masque(format!("h2 ready: {e}")))?;

    let req = build_connect_request(&cfg)?;

    let (resp_fut, send_stream) = h2
        .send_request(req, false)
        .map_err(|e| AetherError::Masque(format!("send_request: {e}")))?;
    log_or_debug(
        quiet,
        format!("[h2] connect-ip request sent to {}", cfg.authority),
    );

    let response = resp_fut
        .await
        .map_err(|e| AetherError::Masque(format!("await response: {e}")))?;
    let status = response.status();
    log_or_debug(
        quiet,
        format!("[h2] connect-ip status: {}", status.as_u16()),
    );
    if !status.is_success() {
        return Err(AetherError::Masque(describe_refusal(&response)));
    }

    let mut recv_body = response.into_body();
    let mut capsules = CapsuleParser::new();

    // Sending gets a task of its own. Kept in the receive loop, a send that has
    // to wait for the edge's window to open would stop poll_data from being
    // polled as well, so a busy upload would stall the download alongside it.
    let (sender_tx, sender_rx) = mpsc::channel::<SenderMsg>(16);
    let (outcome_tx, mut sender_outcome) = oneshot::channel::<Result<()>>();
    let sender_task = tokio::spawn(async move {
        let _ = outcome_tx.send(pump_outbound(send_stream, outbound_rx, sender_rx).await);
    });
    let _sender_guard = AbortOnDrop(sender_task.abort_handle());

    let mut validate_deadline: Option<Instant> = None;
    if data_check {
        let framed = masque::encode_datagram_capsule(&probe_packet);
        if sender_tx
            .send(SenderMsg::Capsule(Bytes::from(framed)))
            .await
            .is_err()
        {
            log::debug!("[h2] initial data-plane probe: the send path is gone");
        }
        validate_deadline = Some(Instant::now() + validation_timeout());
        log_or_debug(
            quiet,
            "[h2] validating data-plane (end-to-end probe) before exposing socks5".to_string(),
        );
    } else if !ready_fired {
        ready_fired = true;
        if let Some(tx) = ready_tx.take() {
            let _ = tx.send(());
        }
    }

    let mut probe_interval = tokio::time::interval(DATA_PROBE_RESEND);
    probe_interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);

    let keepalive_period = h2_keepalive_interval();
    let mut keepalive_interval = tokio::time::interval(keepalive_period);
    keepalive_interval.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
    let mut awaiting_pong = false;
    let mut pong_deadline: Option<Instant> = None;
    let keepalive_timeout = h2_keepalive_timeout();

    loop {
        if data_check && !ready_fired {
            if let Some(dl) = validate_deadline {
                if Instant::now() >= dl {
                    log::warn!(
                        "[h2] data-plane validation timed out; edge accepts control but drops traffic"
                    );
                    close_sender(&sender_tx, &mut sender_outcome).await;
                    return Err(AetherError::Masque(
                        "h2 data-plane validation timeout (handshake ok, no traffic)".into(),
                    ));
                }
            }
        }

        if let Some(dl) = pong_deadline {
            if Instant::now() >= dl {
                log::warn!(
                    "[h2] no PING response from edge within {:?}; connection is stalled",
                    keepalive_timeout
                );
                close_sender(&sender_tx, &mut sender_outcome).await;
                return Err(AetherError::Masque("h2 keepalive timeout".into()));
            }
        }

        tokio::select! {
            biased;

            _ = keepalive_interval.tick(), if ready_fired && !awaiting_pong => {
                match ping_pong.send_ping(h2::Ping::opaque()) {
                    Ok(()) => {
                        awaiting_pong = true;
                        pong_deadline = Some(Instant::now() + keepalive_timeout);
                        log::debug!("[h2] keepalive ping sent");
                    }
                    Err(e) => log::debug!("[h2] keepalive ping send failed: {e}"),
                }
            }

            pong = std::future::poll_fn(|cx| ping_pong.poll_pong(cx)), if awaiting_pong => {
                match pong {
                    Ok(_) => {
                        awaiting_pong = false;
                        pong_deadline = None;
                        log::debug!("[h2] keepalive pong received");
                    }
                    Err(e) => {
                        log::warn!("[h2] keepalive ping failed: {e}");
                        close_sender(&sender_tx, &mut sender_outcome).await;
                        return Err(AetherError::Masque(format!("h2 keepalive: {e}")));
                    }
                }
            }

            _ = probe_interval.tick(), if data_check && !ready_fired => {
                let framed = masque::encode_datagram_capsule(&probe_packet);
                if sender_tx.try_send(SenderMsg::Capsule(Bytes::from(framed))).is_err() {
                    log::trace!("[h2] data-plane probe resend was dropped");
                }
            }

            _ = sleep_until_deadline(pong_deadline) => {}

            ctrl = ctrl_rx.recv() => {
                match ctrl {
                    Some(Control::Close) | None => {
                        close_sender(&sender_tx, &mut sender_outcome).await;
                        log_or_debug(quiet, "[h2] closing tunnel".to_string());
                        return Ok(());
                    }
                    Some(Control::Migrate) => {}
                }
            }

            outcome = &mut sender_outcome => {
                return match outcome {
                    Ok(Ok(())) => {
                        log_or_debug(quiet, "[h2] send path closed".to_string());
                        Ok(())
                    }
                    Ok(Err(e)) => {
                        log::debug!("[h2] send: {e}");
                        Err(e)
                    }
                    Err(_) => Err(AetherError::Masque("h2 send task stopped".into())),
                };
            }

            data = futures::future::poll_fn(|cx| recv_body.poll_data(cx)) => {
                match data {
                    Some(Ok(chunk)) => {
                        let _ = recv_body.flow_control().release_capacity(chunk.len());
                        capsules.push(&chunk);
                        let got_data = drain_capsules(&mut capsules, &inbound_tx, &addr_tx);
                        if got_data && !ready_fired {
                            validate_successes += 1;
                            log::debug!(
                                "[h2] data-plane round-trip {}/{} confirmed",
                                validate_successes, DATA_PROBE_REQUIRED_SUCCESSES
                            );
                            if validate_successes >= DATA_PROBE_REQUIRED_SUCCESSES {
                                ready_fired = true;
                                validate_deadline = None;
                                if let Some(tx) = ready_tx.take() {
                                    let _ = tx.send(());
                                }
                                log_or_debug(quiet, "[h2] tunnel validated (end-to-end data confirmed); exposing socks5".to_string());
                            } else {
                                let framed = masque::encode_datagram_capsule(&probe_packet);
                                if sender_tx
                                    .try_send(SenderMsg::Capsule(Bytes::from(framed)))
                                    .is_err()
                                {
                                    log::trace!("[h2] follow-up data-plane probe was dropped");
                                }
                            }
                        }
                    }
                    Some(Err(e)) => {
                        log::warn!("[h2] recv body error: {e}");
                        return Err(AetherError::Masque(format!("h2 body: {e}")));
                    }
                    None => {
                        log_or_debug(quiet, "[h2] server closed stream".to_string());
                        return Ok(());
                    }
                }
            }
        }
    }
}

/// Ends the request stream and waits briefly for the send task to get the
/// closing frame out before the connection is torn down.
async fn close_sender(
    sender_tx: &mpsc::Sender<SenderMsg>,
    outcome: &mut oneshot::Receiver<Result<()>>,
) {
    if sender_tx.send(SenderMsg::Finish).await.is_ok() {
        let _ = tokio::time::timeout(SENDER_CLOSE_GRACE, outcome).await;
    }
}

/// Owns the request stream and is the only thing that writes to it, so capsules
/// cannot interleave and a wait for send capacity costs nothing but upload.
async fn pump_outbound(
    mut send: h2::SendStream<Bytes>,
    mut outbound_rx: mpsc::Receiver<Vec<u8>>,
    mut control_rx: mpsc::Receiver<SenderMsg>,
) -> Result<()> {
    let mut batch: Vec<u8> = Vec::with_capacity(H2_SEND_BATCH_BYTES);

    loop {
        tokio::select! {
            biased;

            msg = control_rx.recv() => {
                match msg {
                    Some(SenderMsg::Capsule(framed)) => send_capsule(&mut send, framed).await?,
                    Some(SenderMsg::Finish) | None => {
                        let _ = send.send_data(Bytes::new(), true);
                        return Ok(());
                    }
                }
            }

            packet = outbound_rx.recv() => {
                let Some(packet) = packet else {
                    let _ = send.send_data(Bytes::new(), true);
                    return Ok(());
                };

                masque::append_datagram_capsule(&mut batch, &packet);

                // Anything already queued behind this packet rides along, so a
                // burst costs one frame rather than one frame per packet.
                while batch.len() < H2_SEND_BATCH_BYTES {
                    match outbound_rx.try_recv() {
                        Ok(next) => masque::append_datagram_capsule(&mut batch, &next),
                        Err(_) => break,
                    }
                }

                let framed = Bytes::copy_from_slice(&batch);
                batch.clear();
                send_capsule(&mut send, framed).await?;
            }
        }
    }
}

async fn send_capsule(send: &mut h2::SendStream<Bytes>, data: Bytes) -> Result<()> {
    let len = data.len();
    if len == 0 {
        return Ok(());
    }

    send.reserve_capacity(len);
    while send.capacity() < len {
        match futures::future::poll_fn(|cx| send.poll_capacity(cx)).await {
            Some(Ok(_)) => {}
            Some(Err(e)) => return Err(AetherError::Masque(format!("h2 capacity: {e}"))),
            None => return Err(AetherError::Masque("h2 stream closed".into())),
        }
    }

    send.send_data(data, false)
        .map_err(|e| AetherError::Masque(format!("h2 send_data: {e}")))?;
    Ok(())
}

fn drain_capsules(
    capsules: &mut CapsuleParser,
    inbound_tx: &mpsc::Sender<Vec<u8>>,
    addr_tx: &Option<mpsc::Sender<AssignedAddr>>,
) -> bool {
    let mut delivered = false;
    loop {
        match capsules.next() {
            Ok(Some(Capsule::Datagram(payload))) => {
                let pkt = match masque::strip_datagram_context(&payload) {
                    Some(inner) => inner,
                    None => {
                        log::trace!("[h2] discarding a datagram that is not an ip packet");
                        continue;
                    }
                };
                delivered = true;
                match inbound_tx.try_send(pkt) {
                    Ok(()) => {}
                    Err(mpsc::error::TrySendError::Full(_)) => {
                        log::trace!("[h2] inbound queue full, dropping datagram");
                    }
                    Err(mpsc::error::TrySendError::Closed(_)) => return delivered,
                }
            }
            Ok(Some(Capsule::AddressAssign(addrs))) => {
                for a in addrs {
                    if let Some(ip) = bytes_to_ip(a.ip_version, &a.address) {
                        log::info!("[h2] edge assigned {}/{}", ip, a.prefix_len);
                        if let Some(tx) = addr_tx {
                            let _ = tx.try_send(AssignedAddr {
                                ip,
                                prefix: a.prefix_len,
                            });
                        }
                    }
                }
            }
            Ok(Some(Capsule::RouteAdvertisement(routes))) => {
                log::info!("[h2] received {} route advertisements", routes.len());
            }
            Ok(Some(_)) => {}
            Ok(None) => break,
            Err(e) => {
                log::trace!("[h2] capsule parse: {e}");
                break;
            }
        }
    }
    delivered
}

fn bytes_to_ip(version: u8, bytes: &[u8]) -> Option<IpAddr> {
    match version {
        4 if bytes.len() == 4 => Some(IpAddr::V4([bytes[0], bytes[1], bytes[2], bytes[3]].into())),
        6 if bytes.len() == 16 => {
            let mut b = [0u8; 16];
            b.copy_from_slice(bytes);
            Some(IpAddr::V6(b.into()))
        }
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    async fn local_tls_peer(
        alpn: Option<&'static [u8]>,
    ) -> (H2TunnelConfig, tokio::task::JoinHandle<()>) {
        let identity = crate::account::handshake_identity();
        let cert = X509::from_pem(&identity.cert_pem).unwrap();
        let key = PKey::private_key_from_pem(&identity.key_pem).unwrap();
        let pin = ring::digest::digest(
            &ring::digest::SHA256,
            &cert.public_key().unwrap().public_key_to_der().unwrap(),
        )
        .as_ref()
        .to_vec();
        let mut acceptor =
            boring::ssl::SslAcceptor::mozilla_intermediate(SslMethod::tls()).unwrap();
        acceptor.set_certificate(&cert).unwrap();
        acceptor.set_private_key(&key).unwrap();
        if let Some(alpn) = alpn {
            acceptor.set_alpn_select_callback(move |_, offered| {
                boring::ssl::select_next_proto(alpn, offered).ok_or(boring::ssl::AlpnError::NOACK)
            });
        }
        let acceptor = acceptor.build();
        let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let peer = listener.local_addr().unwrap();
        let task = tokio::spawn(async move {
            let (tcp, _) = listener.accept().await.unwrap();
            let _tls = tokio_boring::accept(&acceptor, tcp).await.unwrap();
            std::future::pending::<()>().await;
        });
        (
            H2TunnelConfig {
                peer,
                sni: "localhost".into(),
                authority: "edge.test".into(),
                path: "/".into(),
                cert_pem: identity.cert_pem,
                key_pem: identity.key_pem,
                local_ipv4: Ipv4Addr::new(172, 16, 0, 2),
                quiet: true,
                pin_endpoint: true,
                expected_pins: vec![pin],
                ech_config_list: None,
            },
            task,
        )
    }

    #[tokio::test]
    async fn a_pinned_tls_peer_without_h2_is_rejected_before_sending_a_connect_request() {
        let _upstream = crate::upstream::hold_setting().await;
        let _options = crate::tls::hold_options().await;
        let (cfg, server) = local_tls_peer(Some(b"\x08http/1.1")).await;
        let outcome = tokio::time::timeout(
            Duration::from_secs(3),
            connect_tls(&cfg, FragmentConfig::from_env()),
        )
        .await;
        server.abort();
        let message = match outcome {
            Ok(Err(error)) => error.to_string(),
            _ => panic!("a non-h2 peer must produce a specific ALPN error, without hanging"),
        };
        assert!(message.contains("h2 ALPN"), "{message}");
    }

    #[tokio::test]
    async fn a_pinned_peer_negotiating_h2_still_passes_tls_setup() {
        let _upstream = crate::upstream::hold_setting().await;
        let _options = crate::tls::hold_options().await;
        let (cfg, server) = local_tls_peer(Some(b"\x02h2")).await;
        let outcome = tokio::time::timeout(
            Duration::from_secs(3),
            connect_tls(&cfg, FragmentConfig::from_env()),
        )
        .await;
        server.abort();
        assert!(matches!(outcome, Ok(Ok(_))));
    }

    #[tokio::test]
    async fn a_pinned_legacy_edge_without_alpn_keeps_its_existing_h2_fallback() {
        let _upstream = crate::upstream::hold_setting().await;
        let _options = crate::tls::hold_options().await;
        let (cfg, server) = local_tls_peer(None).await;
        let outcome = tokio::time::timeout(
            Duration::from_secs(3),
            connect_tls(&cfg, FragmentConfig::from_env()),
        )
        .await;
        server.abort();
        assert!(matches!(outcome, Ok(Ok(_))));
    }

    /// A connect-ip stream to an edge that loses the first probe it is sent and
    /// answers every one after it, over memory rather than a network.
    async fn stream_to_an_edge_that_drops_the_first_probe() -> (
        h2::RecvStream,
        h2::SendStream<Bytes>,
        tokio::task::JoinHandle<()>,
    ) {
        let (client_io, edge_io) = tokio::io::duplex(64 * 1024);

        let edge = tokio::spawn(async move {
            let mut connection = h2::server::handshake(edge_io)
                .await
                .expect("the edge's side of the handshake");
            let (request, mut respond) = connection
                .accept()
                .await
                .expect("a request")
                .expect("a well-formed request");
            tokio::spawn(async move { while connection.accept().await.is_some() {} });

            let mut send = respond
                .send_response(http::Response::new(()), false)
                .expect("an answer to the request");
            let mut body = request.into_body();
            let mut capsules = CapsuleParser::new();
            let mut probes = 0;
            while let Some(Ok(chunk)) = body.data().await {
                let _ = body.flow_control().release_capacity(chunk.len());
                capsules.push(&chunk);
                while let Ok(Some(capsule)) = capsules.next() {
                    if let Capsule::Datagram(packet) = capsule {
                        probes += 1;
                        if probes == 1 {
                            continue;
                        }
                        let answer = masque::encode_datagram_capsule(&packet);
                        if send.send_data(Bytes::from(answer), false).is_err() {
                            return;
                        }
                    }
                }
            }
        });

        let (h2, connection) = h2::client::handshake(client_io)
            .await
            .expect("our side of the handshake");
        tokio::spawn(async move {
            let _ = connection.await;
        });
        let mut h2 = h2.ready().await.expect("a connection ready for a request");
        let request = http::Request::builder()
            .method(Method::CONNECT)
            .uri("https://edge.test:443")
            .body(())
            .expect("a request");
        let (response, send) = h2.send_request(request, false).expect("a stream");
        let response = response.await.expect("the edge's answer");
        (response.into_body(), send, edge)
    }

    #[tokio::test]
    async fn a_lost_probe_is_sent_again_rather_than_waited_out() {
        let (mut recv, mut send, edge) = stream_to_an_edge_that_drops_the_first_probe().await;
        let probe = masque::build_dns_probe_packet(Ipv4Addr::new(172, 16, 0, 2));

        let started = Instant::now();
        let proved = tokio::time::timeout(
            Duration::from_secs(5),
            prove_data_plane(&mut recv, &mut send, &probe),
        )
        .await;

        assert!(
            matches!(proved, Ok(Ok(()))),
            "one lost probe must not cost a working edge its verdict: {proved:?}"
        );
        assert!(
            started.elapsed() < Duration::from_secs(3),
            "the lost probe cost {:?}: that is waiting for the timeout, not sending again",
            started.elapsed()
        );
        edge.abort();
    }

    #[tokio::test]
    async fn a_check_that_stalls_after_tls_says_so_rather_than_just_timing_out() {
        let _upstream = crate::upstream::hold_setting().await;
        let _options = crate::tls::hold_options().await;
        let (cfg, server) = local_tls_peer(Some(b"\x02h2")).await;
        let outcome =
            verify_h2_bounded(&cfg, Some(Duration::from_secs(3)), Duration::from_secs(2)).await;
        server.abort();
        let message = outcome
            .expect_err("a peer that never answers HTTP/2 cannot pass")
            .to_string();
        assert!(message.contains("timeout after 2s"), "{message}");
        // It connected and finished TLS, so the words must not blame either.
        assert!(!message.contains("no TCP connection"), "{message}");
        assert!(!message.contains("TLS handshake"), "{message}");
    }

    #[tokio::test]
    async fn a_closed_port_is_a_refusal_worth_one_more_try_and_no_more() {
        let _upstream = crate::upstream::hold_setting().await;
        let _options = crate::tls::hold_options().await;
        // Bound and dropped: nothing listens there now, so the connect is refused.
        let peer = std::net::TcpListener::bind("127.0.0.1:0")
            .unwrap()
            .local_addr()
            .unwrap();
        let (mut cfg, server) = local_tls_peer(Some(b"\x02h2")).await;
        server.abort();
        cfg.peer = peer;

        let tries = std::sync::atomic::AtomicUsize::new(0);
        let outcome = once_more_if_refused(Duration::from_secs(5), || {
            tries.fetch_add(1, Ordering::SeqCst);
            verify_h2_bounded(&cfg, Some(Duration::from_secs(3)), Duration::from_secs(4))
        })
        .await;
        let error = outcome.expect_err("nothing listens there");
        assert!(refused_in_passing(&error), "{error}");
        assert_eq!(
            tries.load(Ordering::SeqCst),
            2,
            "asked once more, and only once"
        );
    }

    #[tokio::test]
    async fn an_answer_that_is_not_a_refusal_is_not_asked_twice() {
        let tries = std::sync::atomic::AtomicUsize::new(0);
        let outcome: Result<()> = once_more_if_refused(Duration::from_secs(5), || {
            tries.fetch_add(1, Ordering::SeqCst);
            async {
                Err(AetherError::Other(
                    "h2 verify timeout after 15s: no data".into(),
                ))
            }
        })
        .await;
        assert!(outcome.is_err());
        assert_eq!(tries.load(Ordering::SeqCst), 1);
    }

    #[test]
    fn refusals_and_resets_are_told_apart_from_answers() {
        use std::io::{Error, ErrorKind};
        for kind in [
            ErrorKind::ConnectionRefused,
            ErrorKind::ConnectionReset,
            ErrorKind::ConnectionAborted,
        ] {
            assert!(
                refused_in_passing(&AetherError::Io(Error::from(kind))),
                "{kind:?}"
            );
        }
        assert!(refused_in_passing(&AetherError::Tls(
            "h2 tls handshake: TLS handshake failed unexpected EOF".into()
        )));
        assert!(refused_in_passing(&AetherError::Tls(
            "h2 tls handshake: An existing connection was forcibly closed by the remote host. (os error 10054)".into()
        )));
        for answer in [
            AetherError::Io(Error::new(ErrorKind::TimedOut, "tcp connect timed out after 5s")),
            AetherError::Tls(
                "h2 tls handshake: TLS handshake failed: cert verification failed - application verification failure".into(),
            ),
            AetherError::Masque("connect-ip status 403: refused".into()),
            AetherError::Other("h2 verify timeout after 15s: no data came back through the tunnel".into()),
            // Words alone are not enough outside a TLS error.
            AetherError::Other("the edge refused the request".into()),
        ] {
            assert!(!refused_in_passing(&answer), "{answer}");
        }
    }

    #[test]
    fn only_a_handshake_turned_down_for_its_ech_config_is_made_again() {
        assert!(rejected_ech("TLS handshake failed [ECH_REJECTED]"));
        assert!(!rejected_ech("TLS handshake failed [WRONG_VERSION_NUMBER]"));
        assert!(!rejected_ech("unknown BoringSSL error"));
        assert!(!rejected_ech("the SSL session has been shut down"));
    }
}
