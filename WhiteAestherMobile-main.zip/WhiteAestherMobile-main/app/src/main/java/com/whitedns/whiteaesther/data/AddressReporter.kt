package com.whitedns.whiteaesther.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import com.whitedns.whiteaesther.core.CarriedSocket
import java.net.HttpURLConnection
import java.net.URL

/**
 * Which address the internet sees, before the tunnel and after it.
 *
 * Cloudflare's own trace endpoint answers both questions. It is not a neutral
 * choice and it is not an arbitrary one: the tunnel already terminates on
 * Cloudflare, so asking them tells them nothing they do not already handle, and
 * it is reachable on networks where a general-purpose "what is my IP" service
 * is not. Adding a third party here would mean handing this device's real
 * address to someone who had no part in carrying its traffic.
 */
/**
 * What the trace endpoint said about the far end of the tunnel.
 *
 * [country] is Cloudflare's `loc`: two letters, or one of its own codes such as
 * `T1` for Tor, or null when the answer had none. [latencyMs] is the time the
 * whole request took through the tunnel, connection and TLS included -- a real
 * page load's delay, which is what "ping" means to someone using the app.
 */
data class TunnelExit(val ip: String, val country: String?, val latencyMs: Long)

object AddressReporter {
    /**
     * The host the trace endpoint lives on, for the request made by hand
     * through a carrier. Sent as a name, so the carrier resolves it.
     */
    private const val TRACE_HOST = "www.cloudflare.com"

    private const val TRACE_PATH = "/cdn-cgi/trace"

    /**
     * The same endpoint as a URL, for the direct lookup that uses this phone's
     * own resolver.
     *
     * Cloudflare answers over whichever family the connection used, and the
     * hostname carries both records -- so on a dual-stack network Java picks
     * IPv6 and the answer is an IPv6 address regardless of what the user asked
     * for, which is what [TRACE_V4] is for.
     */
    private const val TRACE_URL = "https://www.cloudflare.com/cdn-cgi/trace"

    /**
     * The same endpoint reached over IPv4 only.
     *
     * An address literal rather than a name, because a name is what let the
     * resolver choose. Cloudflare's certificate covers this address, so TLS
     * still verifies.
     */
    private const val TRACE_V4 = "https://1.1.1.1/cdn-cgi/trace"

    private const val TIMEOUT_MS = 6_000

    /**
     * Longer than the direct one, and generously so.
     *
     * This is three hops rather than none, and on meek every one of them is a
     * CDN round trip -- measured at over twenty seconds for a single request on
     * a working circuit. Nothing waits on this but a row on a screen, so the
     * cost of being patient is a field that fills in late, and the cost of not
     * being is a blank one under a tunnel that is working.
     */
    private const val CARRIER_TIMEOUT_MS = 60_000

    private val Context.addressStore by preferencesDataStore(name = "whiteaesther_address")
    private val REAL_ADDRESS = stringPreferencesKey("real_address")

    /**
     * The address this device has without the tunnel.
     *
     * Read once, while disconnected, and remembered. Refreshing it during a
     * session would mean sending the user's real address out past the tunnel
     * that exists to hide it -- so the stored answer goes stale instead, and a
     * stale answer is the safe one to be wrong about.
     */
    suspend fun realAddress(context: Context, ipv4Only: Boolean = false): String? =
        context.addressStore.data.first()[REAL_ADDRESS]
            ?.takeUnless(String::isBlank)
            // A stored answer outlives the setting that produced it. One
            // captured over IPv6 kept being shown after the user switched to
            // IPv4 only, which reads exactly like the switch doing nothing.
            ?.takeIf { !ipv4Only || !it.contains(':') }

    /**
     * Looks the real address up and stores it. Only safe while disconnected.
     *
     * The caller is responsible for that: there is nothing in a socket that
     * says whether a tunnel is up, so this cannot check for itself.
     */
    suspend fun captureRealAddress(context: Context, ipv4Only: Boolean = false): String? {
        val address = fetch(ipv4Only)?.ip ?: return null
        context.addressStore.edit { preferences -> preferences[REAL_ADDRESS] = address }
        return address
    }

    /**
     * The address seen from inside the tunnel.
     *
     * Not stored. It belongs to one session, and showing the previous session's
     * exit while a new one is negotiating would be a confident lie.
     */
    suspend fun tunnelAddress(ipv4Only: Boolean = false): String? = tunnelExit(ipv4Only)?.ip

    /** [tunnelAddress] with the exit's country and the request's delay. */
    suspend fun tunnelExit(ipv4Only: Boolean = false): TunnelExit? = fetch(ipv4Only)

    /**
     * The address seen from beyond a carrier, asked through the carrier itself.
     *
     * [tunnelAddress] cannot answer this. It dials from this process, and this
     * process is excluded from the interface, so what it measures on a carrier
     * session is the phone's own address -- reported under a heading that says
     * the opposite.
     *
     * By name rather than by literal, unlike everywhere else here. The address
     * form is how the direct lookup avoids the resolver choosing IPv6, and it
     * is exactly wrong through a carrier: Psiphon's servers refuse a port
     * forward to 1.1.1.1, and a name is resolved at the far end where it also
     * cannot leak.
     *
     * Which is why this is written by hand rather than through
     * `URL.openConnection(proxy)`. That resolves the name on this device before
     * it dials, so the row said nothing at all on exactly the networks where a
     * carrier is worth having -- see [CarriedSocket], which is also where the
     * certificate gets checked against the name.
     */
    suspend fun carrierAddress(socksPort: Int): String? = carrierExit(socksPort)?.ip

    /** [carrierAddress] with the exit's country and the request's delay. */
    suspend fun carrierExit(socksPort: Int): TunnelExit? = withContext(Dispatchers.IO) {
        runCatching {
            val started = System.nanoTime()
            val answer = CarriedSocket.request(
                host = TRACE_HOST,
                path = TRACE_PATH,
                socksPort = socksPort,
                timeoutMs = CARRIER_TIMEOUT_MS,
            )
            parseTrace(answer.body, (System.nanoTime() - started) / 1_000_000)
        }.getOrNull()
    }

    /** Reads `ip=` and `loc=` from a trace answer; null without an address. */
    internal fun parseTrace(body: String, latencyMs: Long): TunnelExit? {
        val fields = body.lineSequence().mapNotNull { line ->
            line.split('=', limit = 2).takeIf { it.size == 2 }?.let { it[0].trim() to it[1].trim() }
        }.toMap()
        val ip = fields["ip"]?.takeUnless(String::isBlank) ?: return null
        return TunnelExit(ip, fields["loc"]?.takeUnless(String::isBlank), latencyMs)
    }

    /**
     * Reads the address, over the family the user chose.
     *
     * When they have turned IPv6 off and only an IPv6 answer can be had, this
     * returns null rather than the answer. Showing an IPv6 address on a screen
     * where the user has switched IPv6 off reads as the setting being ignored,
     * which is worse than an empty field.
     */
    private suspend fun fetch(ipv4Only: Boolean): TunnelExit? {
        // IPv4 first, always. The two rows exist to be compared, and they
        // cannot be when one is IPv6 and the other IPv4 -- which is what a
        // dual-stack phone produced, because the resolver prefers IPv6 for the
        // direct lookup while the tunnel exits on IPv4.
        request(TRACE_V4)?.let { return it }
        // Only when IPv4 could not be had at all: a v6-only network, or a
        // network where the literal is blocked. Better a v6 answer than none.
        return if (ipv4Only) null else request(TRACE_URL)
    }

    private suspend fun request(url: String): TunnelExit? = withContext(Dispatchers.IO) {
        runCatching {
            val started = System.nanoTime()
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = TIMEOUT_MS
                readTimeout = TIMEOUT_MS
                requestMethod = "GET"
                // The endpoint answers plain text either way; an empty agent
                // matches what the engine sends and keeps the two consistent.
                setRequestProperty("User-Agent", "")
            }
            try {
                if (connection.responseCode != HttpURLConnection.HTTP_OK) return@runCatching null
                val body = connection.inputStream.bufferedReader().readText()
                parseTrace(body, (System.nanoTime() - started) / 1_000_000)
            } finally {
                connection.disconnect()
            }
        }.getOrNull()
    }
}
